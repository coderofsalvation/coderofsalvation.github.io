What is it?
===========
This application generates timeline-specific code.
(basically its a code-snippet-template-engine, which can produce timeline code)
It was made with audio/video beatsyncing/fx in mind, and triggering freeframe plugins at certain places in videos.
If you get the idea, you can use it for any programming language.
Started out as a tool for generating avisynthcode, and evolved into a cross-scripting language utility.

Why
===
To easify generation of time-critical code for scripters.
Lots of time, when combining audio & video, I wanted to trigger code at specific timestamps.
After lots of realtime experiences (by binding MIDI/OSC events to certain video-events), I decided that
these methods are often very unportable/obscure/complex.
Also, often they relay on realtime analyzation of audio, which causes a lot of 'false triggers'.
I wanted just 1 file containing my triggerdata, which I can use in whatever application.
This would be much better then using multiple programs to create timeline-specific fx for content creation.

So, just to have great video content, synced to audio, we should get away from realtime applications.
However, it would be way to much work to write down code manually.
After lots of research I discovered avisynth was a rich videoscripting language with a respectable community.
So I have my scripting language, but now..how to get the triggers?

I discovered VAMP plugins, which are basically audiodetection algorythms.
Then I discovered a free great trigger-editor/VAMP host called 'Sonic Visualizer'.
Here you can load up an audiofile, set triggers by mouse (or by detectionalgorythms), and export the triggers to xml.

This was exactly what I wanted...the comfort of generating triggers, and the ability to set manual triggers.
Now I needed to convert these triggers to actual avisynth-code: avs-vjgen was born.


How to use
==========

First download avisynth & watch some youtubes about it.
Also, Use (44100khz) audio at all time, and import your code with: Import('yourgeneratedfile.avs')

automatically generate triggers according to bpm:

1) enter fps of your video
2) enter the outfile (this is where the code will be written)
3) enter the bpm
4) enter the triggers (this is how many times the code trigger template will be outputted)
5) enter the triggerframes (how many frames should a trigger last?)
6) select/edit your code template
5) select 'Code Generation Type' = 'Calculate BPM-related triggers'
6) hit process 
7) in your .avs file add 'Import('youroutfile.avs')

convert triggers from 'Sonic Visualizer' into code:

1) enter fps of your video
2) enter the outfile (this is where the code will be written)
3) enter the triggerframes (how many frames should a trigger last?)
4) select/edit your code template
5) select 'Code Generation Type' = 'Use Sonic Visualizer Annotation'
6) hit process
7) in your .avs file add 'Import('youroutfile.avs')

The 'template variables'
========================
In the code snippets you will see strange words like: {$foo}
These are keywords, which get replaced by a generated value :

{$start}               = calculated video-frame number of trigger
{$end}                 = calculated video-frame number of trigger PLUS the value in the triggerframes-input
{$triggerframes}       = gets replaced by what you enter in the triggerframes-input
{$beatframes}          = is the distance in videoframes between {$start} and {$end}
{$cyclevar}            = this value will be picked from the cyclevar-input (in incremental order)
                         So if you enter '0,1,2' as cyclevar, and 'hello I am {$cyclevar}' in the template,
                         the output would be:

                         hello I am 0
                         hello I am 1
                         hello I am 2


Who
===
I made this (The Coder Of Salvation / Leon van Kammen )
Feel free to improve this utility.
