
# BEGIN-OF-GENERATED-OUTPUT
# example to generate blender keyframe when triggers occur
# don't forget to put 'import Blender' at the top of your generated script

# set keyframe to reset to origin
obj = Blender.Object.Get('Cube.001')
Blender.Set("curframe",0-1)
obj.setSize(1.0,1.0,1.0)
obj.insertIpoKey(Blender.Object.SIZE)
# set keyframe
obj = Blender.Object.Get('Cube.001')
Blender.Set("curframe",0)
obj.setSize(1.0,1.0,10.0)
obj.insertIpoKey(Blender.Object.SIZE)

# example to generate blender keyframe when triggers occur
# don't forget to put 'import Blender' at the top of your generated script

# set keyframe to reset to origin
obj = Blender.Object.Get('Cube.002')
Blender.Set("curframe",1-1)
obj.setSize(1.0,1.0,1.0)
obj.insertIpoKey(Blender.Object.SIZE)
# set keyframe
obj = Blender.Object.Get('Cube.002')
Blender.Set("curframe",1)
obj.setSize(1.0,1.0,10.0)
obj.insertIpoKey(Blender.Object.SIZE)

# example to generate blender keyframe when triggers occur
# don't forget to put 'import Blender' at the top of your generated script

# set keyframe to reset to origin
obj = Blender.Object.Get('Cube.003')
Blender.Set("curframe",2-1)
obj.setSize(1.0,1.0,1.0)
obj.insertIpoKey(Blender.Object.SIZE)
# set keyframe
obj = Blender.Object.Get('Cube.003')
Blender.Set("curframe",2)
obj.setSize(1.0,1.0,10.0)
obj.insertIpoKey(Blender.Object.SIZE)

# example to generate blender keyframe when triggers occur
# don't forget to put 'import Blender' at the top of your generated script

# set keyframe to reset to origin
obj = Blender.Object.Get('Cube.004')
Blender.Set("curframe",3-1)
obj.setSize(1.0,1.0,1.0)
obj.insertIpoKey(Blender.Object.SIZE)
# set keyframe
obj = Blender.Object.Get('Cube.004')
Blender.Set("curframe",3)
obj.setSize(1.0,1.0,10.0)
obj.insertIpoKey(Blender.Object.SIZE)

# example to generate blender keyframe when triggers occur
# don't forget to put 'import Blender' at the top of your generated script

# set keyframe to reset to origin
obj = Blender.Object.Get('Cube.001')
Blender.Set("curframe",4-1)
obj.setSize(1.0,1.0,1.0)
obj.insertIpoKey(Blender.Object.SIZE)
# set keyframe
obj = Blender.Object.Get('Cube.001')
Blender.Set("curframe",4)
obj.setSize(1.0,1.0,10.0)
obj.insertIpoKey(Blender.Object.SIZE)

# example to generate blender keyframe when triggers occur
# don't forget to put 'import Blender' at the top of your generated script

# set keyframe to reset to origin
obj = Blender.Object.Get('Cube.002')
Blender.Set("curframe",6-1)
obj.setSize(1.0,1.0,1.0)
obj.insertIpoKey(Blender.Object.SIZE)
# set keyframe
obj = Blender.Object.Get('Cube.002')
Blender.Set("curframe",6)
obj.setSize(1.0,1.0,10.0)
obj.insertIpoKey(Blender.Object.SIZE)

# example to generate blender keyframe when triggers occur
# don't forget to put 'import Blender' at the top of your generated script

# set keyframe to reset to origin
obj = Blender.Object.Get('Cube.003')
Blender.Set("curframe",7-1)
obj.setSize(1.0,1.0,1.0)
obj.insertIpoKey(Blender.Object.SIZE)
# set keyframe
obj = Blender.Object.Get('Cube.003')
Blender.Set("curframe",7)
obj.setSize(1.0,1.0,10.0)
obj.insertIpoKey(Blender.Object.SIZE)

# example to generate blender keyframe when triggers occur
# don't forget to put 'import Blender' at the top of your generated script

# set keyframe to reset to origin
obj = Blender.Object.Get('Cube.004')
Blender.Set("curframe",9-1)
obj.setSize(1.0,1.0,1.0)
obj.insertIpoKey(Blender.Object.SIZE)
# set keyframe
obj = Blender.Object.Get('Cube.004')
Blender.Set("curframe",9)
obj.setSize(1.0,1.0,10.0)
obj.insertIpoKey(Blender.Object.SIZE)

# example to generate blender keyframe when triggers occur
# don't forget to put 'import Blender' at the top of your generated script

# set keyframe to reset to origin
obj = Blender.Object.Get('Cube.001')
Blender.Set("curframe",11-1)
obj.setSize(1.0,1.0,1.0)
obj.insertIpoKey(Blender.Object.SIZE)
# set keyframe
obj = Blender.Object.Get('Cube.001')
Blender.Set("curframe",11)
obj.setSize(1.0,1.0,10.0)
obj.insertIpoKey(Blender.Object.SIZE)

# example to generate blender keyframe when triggers occur
# don't forget to put 'import Blender' at the top of your generated script

# set keyframe to reset to origin
obj = Blender.Object.Get('Cube.002')
Blender.Set("curframe",13-1)
obj.setSize(1.0,1.0,1.0)
obj.insertIpoKey(Blender.Object.SIZE)
# set keyframe
obj = Blender.Object.Get('Cube.002')
Blender.Set("curframe",13)
obj.setSize(1.0,1.0,10.0)
obj.insertIpoKey(Blender.Object.SIZE)

# example to generate blender keyframe when triggers occur
# don't forget to put 'import Blender' at the top of your generated script

# set keyframe to reset to origin
obj = Blender.Object.Get('Cube.003')
Blender.Set("curframe",15-1)
obj.setSize(1.0,1.0,1.0)
obj.insertIpoKey(Blender.Object.SIZE)
# set keyframe
obj = Blender.Object.Get('Cube.003')
Blender.Set("curframe",15)
obj.setSize(1.0,1.0,10.0)
obj.insertIpoKey(Blender.Object.SIZE)

# example to generate blender keyframe when triggers occur
# don't forget to put 'import Blender' at the top of your generated script

# set keyframe to reset to origin
obj = Blender.Object.Get('Cube.004')
Blender.Set("curframe",17-1)
obj.setSize(1.0,1.0,1.0)
obj.insertIpoKey(Blender.Object.SIZE)
# set keyframe
obj = Blender.Object.Get('Cube.004')
Blender.Set("curframe",17)
obj.setSize(1.0,1.0,10.0)
obj.insertIpoKey(Blender.Object.SIZE)

# example to generate blender keyframe when triggers occur
# don't forget to put 'import Blender' at the top of your generated script

# set keyframe to reset to origin
obj = Blender.Object.Get('Cube.001')
Blender.Set("curframe",19-1)
obj.setSize(1.0,1.0,1.0)
obj.insertIpoKey(Blender.Object.SIZE)
# set keyframe
obj = Blender.Object.Get('Cube.001')
Blender.Set("curframe",19)
obj.setSize(1.0,1.0,10.0)
obj.insertIpoKey(Blender.Object.SIZE)

# example to generate blender keyframe when triggers occur
# don't forget to put 'import Blender' at the top of your generated script

# set keyframe to reset to origin
obj = Blender.Object.Get('Cube.002')
Blender.Set("curframe",22-1)
obj.setSize(1.0,1.0,1.0)
obj.insertIpoKey(Blender.Object.SIZE)
# set keyframe
obj = Blender.Object.Get('Cube.002')
Blender.Set("curframe",22)
obj.setSize(1.0,1.0,10.0)
obj.insertIpoKey(Blender.Object.SIZE)

# example to generate blender keyframe when triggers occur
# don't forget to put 'import Blender' at the top of your generated script

# set keyframe to reset to origin
obj = Blender.Object.Get('Cube.003')
Blender.Set("curframe",24-1)
obj.setSize(1.0,1.0,1.0)
obj.insertIpoKey(Blender.Object.SIZE)
# set keyframe
obj = Blender.Object.Get('Cube.003')
Blender.Set("curframe",24)
obj.setSize(1.0,1.0,10.0)
obj.insertIpoKey(Blender.Object.SIZE)

# example to generate blender keyframe when triggers occur
# don't forget to put 'import Blender' at the top of your generated script

# set keyframe to reset to origin
obj = Blender.Object.Get('Cube.004')
Blender.Set("curframe",27-1)
obj.setSize(1.0,1.0,1.0)
obj.insertIpoKey(Blender.Object.SIZE)
# set keyframe
obj = Blender.Object.Get('Cube.004')
Blender.Set("curframe",27)
obj.setSize(1.0,1.0,10.0)
obj.insertIpoKey(Blender.Object.SIZE)

# example to generate blender keyframe when triggers occur
# don't forget to put 'import Blender' at the top of your generated script

# set keyframe to reset to origin
obj = Blender.Object.Get('Cube.001')
Blender.Set("curframe",31-1)
obj.setSize(1.0,1.0,1.0)
obj.insertIpoKey(Blender.Object.SIZE)
# set keyframe
obj = Blender.Object.Get('Cube.001')
Blender.Set("curframe",31)
obj.setSize(1.0,1.0,10.0)
obj.insertIpoKey(Blender.Object.SIZE)

# example to generate blender keyframe when triggers occur
# don't forget to put 'import Blender' at the top of your generated script

# set keyframe to reset to origin
obj = Blender.Object.Get('Cube.002')
Blender.Set("curframe",34-1)
obj.setSize(1.0,1.0,1.0)
obj.insertIpoKey(Blender.Object.SIZE)
# set keyframe
obj = Blender.Object.Get('Cube.002')
Blender.Set("curframe",34)
obj.setSize(1.0,1.0,10.0)
obj.insertIpoKey(Blender.Object.SIZE)

# example to generate blender keyframe when triggers occur
# don't forget to put 'import Blender' at the top of your generated script

# set keyframe to reset to origin
obj = Blender.Object.Get('Cube.003')
Blender.Set("curframe",39-1)
obj.setSize(1.0,1.0,1.0)
obj.insertIpoKey(Blender.Object.SIZE)
# set keyframe
obj = Blender.Object.Get('Cube.003')
Blender.Set("curframe",39)
obj.setSize(1.0,1.0,10.0)
obj.insertIpoKey(Blender.Object.SIZE)

# example to generate blender keyframe when triggers occur
# don't forget to put 'import Blender' at the top of your generated script

# set keyframe to reset to origin
obj = Blender.Object.Get('Cube.004')
Blender.Set("curframe",44-1)
obj.setSize(1.0,1.0,1.0)
obj.insertIpoKey(Blender.Object.SIZE)
# set keyframe
obj = Blender.Object.Get('Cube.004')
Blender.Set("curframe",44)
obj.setSize(1.0,1.0,10.0)
obj.insertIpoKey(Blender.Object.SIZE)

# example to generate blender keyframe when triggers occur
# don't forget to put 'import Blender' at the top of your generated script

# set keyframe to reset to origin
obj = Blender.Object.Get('Cube.001')
Blender.Set("curframe",49-1)
obj.setSize(1.0,1.0,1.0)
obj.insertIpoKey(Blender.Object.SIZE)
# set keyframe
obj = Blender.Object.Get('Cube.001')
Blender.Set("curframe",49)
obj.setSize(1.0,1.0,10.0)
obj.insertIpoKey(Blender.Object.SIZE)

# example to generate blender keyframe when triggers occur
# don't forget to put 'import Blender' at the top of your generated script

# set keyframe to reset to origin
obj = Blender.Object.Get('Cube.002')
Blender.Set("curframe",55-1)
obj.setSize(1.0,1.0,1.0)
obj.insertIpoKey(Blender.Object.SIZE)
# set keyframe
obj = Blender.Object.Get('Cube.002')
Blender.Set("curframe",55)
obj.setSize(1.0,1.0,10.0)
obj.insertIpoKey(Blender.Object.SIZE)

# example to generate blender keyframe when triggers occur
# don't forget to put 'import Blender' at the top of your generated script

# set keyframe to reset to origin
obj = Blender.Object.Get('Cube.003')
Blender.Set("curframe",62-1)
obj.setSize(1.0,1.0,1.0)
obj.insertIpoKey(Blender.Object.SIZE)
# set keyframe
obj = Blender.Object.Get('Cube.003')
Blender.Set("curframe",62)
obj.setSize(1.0,1.0,10.0)
obj.insertIpoKey(Blender.Object.SIZE)

# example to generate blender keyframe when triggers occur
# don't forget to put 'import Blender' at the top of your generated script

# set keyframe to reset to origin
obj = Blender.Object.Get('Cube.004')
Blender.Set("curframe",70-1)
obj.setSize(1.0,1.0,1.0)
obj.insertIpoKey(Blender.Object.SIZE)
# set keyframe
obj = Blender.Object.Get('Cube.004')
Blender.Set("curframe",70)
obj.setSize(1.0,1.0,10.0)
obj.insertIpoKey(Blender.Object.SIZE)

# example to generate blender keyframe when triggers occur
# don't forget to put 'import Blender' at the top of your generated script

# set keyframe to reset to origin
obj = Blender.Object.Get('Cube.001')
Blender.Set("curframe",78-1)
obj.setSize(1.0,1.0,1.0)
obj.insertIpoKey(Blender.Object.SIZE)
# set keyframe
obj = Blender.Object.Get('Cube.001')
Blender.Set("curframe",78)
obj.setSize(1.0,1.0,10.0)
obj.insertIpoKey(Blender.Object.SIZE)

# example to generate blender keyframe when triggers occur
# don't forget to put 'import Blender' at the top of your generated script

# set keyframe to reset to origin
obj = Blender.Object.Get('Cube.002')
Blender.Set("curframe",88-1)
obj.setSize(1.0,1.0,1.0)
obj.insertIpoKey(Blender.Object.SIZE)
# set keyframe
obj = Blender.Object.Get('Cube.002')
Blender.Set("curframe",88)
obj.setSize(1.0,1.0,10.0)
obj.insertIpoKey(Blender.Object.SIZE)

# example to generate blender keyframe when triggers occur
# don't forget to put 'import Blender' at the top of your generated script

# set keyframe to reset to origin
obj = Blender.Object.Get('Cube.003')
Blender.Set("curframe",98-1)
obj.setSize(1.0,1.0,1.0)
obj.insertIpoKey(Blender.Object.SIZE)
# set keyframe
obj = Blender.Object.Get('Cube.003')
Blender.Set("curframe",98)
obj.setSize(1.0,1.0,10.0)
obj.insertIpoKey(Blender.Object.SIZE)

# example to generate blender keyframe when triggers occur
# don't forget to put 'import Blender' at the top of your generated script

# set keyframe to reset to origin
obj = Blender.Object.Get('Cube.004')
Blender.Set("curframe",101-1)
obj.setSize(1.0,1.0,1.0)
obj.insertIpoKey(Blender.Object.SIZE)
# set keyframe
obj = Blender.Object.Get('Cube.004')
Blender.Set("curframe",101)
obj.setSize(1.0,1.0,10.0)
obj.insertIpoKey(Blender.Object.SIZE)

# example to generate blender keyframe when triggers occur
# don't forget to put 'import Blender' at the top of your generated script

# set keyframe to reset to origin
obj = Blender.Object.Get('Cube.001')
Blender.Set("curframe",110-1)
obj.setSize(1.0,1.0,1.0)
obj.insertIpoKey(Blender.Object.SIZE)
# set keyframe
obj = Blender.Object.Get('Cube.001')
Blender.Set("curframe",110)
obj.setSize(1.0,1.0,10.0)
obj.insertIpoKey(Blender.Object.SIZE)

# example to generate blender keyframe when triggers occur
# don't forget to put 'import Blender' at the top of your generated script

# set keyframe to reset to origin
obj = Blender.Object.Get('Cube.002')
Blender.Set("curframe",124-1)
obj.setSize(1.0,1.0,1.0)
obj.insertIpoKey(Blender.Object.SIZE)
# set keyframe
obj = Blender.Object.Get('Cube.002')
Blender.Set("curframe",124)
obj.setSize(1.0,1.0,10.0)
obj.insertIpoKey(Blender.Object.SIZE)

# example to generate blender keyframe when triggers occur
# don't forget to put 'import Blender' at the top of your generated script

# set keyframe to reset to origin
obj = Blender.Object.Get('Cube.003')
Blender.Set("curframe",138-1)
obj.setSize(1.0,1.0,1.0)
obj.insertIpoKey(Blender.Object.SIZE)
# set keyframe
obj = Blender.Object.Get('Cube.003')
Blender.Set("curframe",138)
obj.setSize(1.0,1.0,10.0)
obj.insertIpoKey(Blender.Object.SIZE)

# example to generate blender keyframe when triggers occur
# don't forget to put 'import Blender' at the top of your generated script

# set keyframe to reset to origin
obj = Blender.Object.Get('Cube.004')
Blender.Set("curframe",155-1)
obj.setSize(1.0,1.0,1.0)
obj.insertIpoKey(Blender.Object.SIZE)
# set keyframe
obj = Blender.Object.Get('Cube.004')
Blender.Set("curframe",155)
obj.setSize(1.0,1.0,10.0)
obj.insertIpoKey(Blender.Object.SIZE)

# END-OF-GENERATED-OUTPUT
